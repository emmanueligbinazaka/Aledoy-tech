<footer>
      <div class="footer">
        <div class="container">
          <div class="row">
            <div class="col-md-3">
              <div class="footer-logo">
                <img src="images/Aledoy-Talent Logo.png" alt="Logo" />
              </div>
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-2">
              <h1>LINKS</h1>
              <ul class="footer-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="for_talents.php">For Talents</a></li>
                <li><a href="for _employeers.php">For Employer</a></li>
              </ul>
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-2">
              <h1>COMPANY</h1>
              <ul class="footer-links">
                <li><a href="#">About</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Events</a></li>
                <li><a href="#">Terms</a></li>
                <li><a href="#">Privacy Policy</a></li>
              </ul>
            </div>
            <!-- Channels Section -->
            <div class="col-md-1"></div>
            <div class="col-md-2">
              <h1>CHANNELS</h1>
              <ul class="footer-links">
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Youtube</a></li>
                <li><a href="#">Instagram</a></li>
              </ul>
            </div>
          </div>
          <hr />
          <p>&copy; Aledoy Training 2025, All Rights Reserved.</p>
        </div>
      </div>
    </footer>