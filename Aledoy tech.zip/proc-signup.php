<?php 

$name = $_POST['firstname'];
$lastname = $_POST['lastname'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$password = $_POST['password'];

if(!$name || !$lastname || !$phone || !$email || !$password)
{
    $msg = 'error';
    $comment = 'All fields are required';
    include('signup.php');
    exit;
}

if (strlen($phone) != 11) 
{
    $phone = '';
    $msg = 'error';
    $comment = 'Please enter valid number';
    include('signup.php');
    exit;
}


   $content = 'Firstname: '.$firstname."\n"
   .'Lastname : '.$lastname."\n"
   .'Phone : '.$phone."\n"
   .'Email : '.$email."\n"
   .'Password : '.$password."\n";

    $to = 'emmanueligbinazaka3@gmail.com';
    $sub = 'Practise Sign Up Form';
    $from = "From: noreply@aledoy.com";
    mail($to,$sub,$content,$from);

    $content = 'Firstname: '.$name."\n"
   .'Lastname : '.$lastname."\n"
   .'Phone : '.$phone."\n"
   .'Email : '.$email."\n"
   .'Password : '.$password."\n"
    .'++++++++++++++++++++++++++++'."\n"."\n";

//write the code to send the details to email
$file = fopen("signup.txt","a");
fwrite($file,$content);
fclose($file);


// $msg = 'success';
include('login.php');

?>