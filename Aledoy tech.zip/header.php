<nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container mt-2">
        <a class="navbar-brand" href="index.php">
          <img src="images/Aledoy-Talent Logo.png" class="" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNavAltMarkup"
          aria-controls="navbarNavAltMarkup"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav mx-auto">
            <a class="nav-link text-dark" href="for_talents.php"
              >For Talents</a
            >
            <a class="nav-link text-dark" href="for _employeers.php"
              >For Employers</a
            >
          </div>
          <div class="buttons">
          <a href="signup.php" style="text-decoration: none; ">
              <p class="differnet" style="width: 100px;">Sign Up</p>
            </a>
            <!-- <p class="mt-3">Contact us</p> -->
            <a href="login.php" style="text-decoration: none">
              <p class="differnet">Login</p>
            </a>
          </div>
        </div>
      </div>
    </nav>