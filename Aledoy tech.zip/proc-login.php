<?php

$email = $_POST['email'];
$password = $_POST['password'];


if($email == '')
{
    $msg = 'error';
    $comment = 'Email required';
    include('login.php');
    exit;
}

if($password == '')
{
    $msg = 'error';
    $comment = 'Password Required';
    include('login.php');
    exit;
}

include('candidate_dashboard.php');

?>